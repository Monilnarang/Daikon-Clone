#ifndef REPORT_BUGS_TO
#define REPORT_BUGS_TO	"bug-binutils@gnu.org"
#endif
